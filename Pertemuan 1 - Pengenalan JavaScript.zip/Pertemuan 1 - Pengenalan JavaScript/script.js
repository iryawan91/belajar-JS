alert('Ini alert dari file eksternal!');
console.log('Ini pesan dari script.js');

console.log('Ini muncul di console!');
let nama = 'Dede';
console.log('Nama saya adalah: ' + nama);
